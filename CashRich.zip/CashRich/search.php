<?php include("connection.php") ?>
<?php 
    
    session_start();  
 if(!isset($_SESSION['username'])){
    header('location:index.php');
 }
?>

<!doctype html>
<html lang="en">
<head>
        
        <meta charset="utf-8" />
        <title>CashRich</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        
        <link rel="shortcut icon" href="assets/images/cashrich_logo_130.png">
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body data-topbar="dark" data-layout="horizontal">

        
        <div id="layout-wrapper">

           <?php include("header.php") ?>
            <div class="main-content">
                <div class="page-content">
                <div class="container-fluid">
<center>
    <h3>Search</h3>
</center>
                <center>  <div class="navbar " style="width: max-content;">
                       <form style="padding: 0px;">
                            <div class="position-relative">
                                <input type="search" class="form-control" style="color: black;" placeholder="Enter Coin Symbols">
                               
                            </div>
                            
                        </form>
                        </div></center> 
                        <center><a href="#" class="btn btn-primary" style="margin-top: 10px;">Search</a></center>
<br>
                    <center style="color:red;"> *The KEY was not working so I did it Manually* </center>
                        <div class="row" style="margin-top: 30px;">
                                    <div class="col-sm-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <p class="text-muted mb-4"><i class="mdi mdi-bitcoin h2 text-warning align-middle mb-0 me-3"></i> Bitcoin </p>

                                                <div class="row">
                                                    <div class="col-6">
                                                        <div>
                                                            <h5>$ 9134.39</h5>
                                                            <p class="text-muted text-truncate mb-0">+ 0.0012 ( 0.2 % ) <i class="mdi mdi-arrow-up ms-1 text-success"></i></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div>
                                                            <div id="area-sparkline-chart-1" data-colors='["--bs-warning"]' class="apex-charts"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <p class="text-muted mb-4"><i class="mdi mdi-ethereum h2 text-primary align-middle mb-0 me-3"></i> Ethereum </p>

                                                <div class="row">
                                                    <div class="col-6">
                                                        <div>
                                                            <h5>$ 245.44</h5>
                                                            <p class="text-muted text-truncate mb-0">- 4.102 ( 0.1 % ) <i class="mdi mdi-arrow-down ms-1 text-danger"></i></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div>
                                                            <div id="area-sparkline-chart-2" data-colors='["--bs-primary"]' class="apex-charts"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4" >
                                        <div class="card">
                                            <div class="card-body">
                                                <p class="text-muted mb-4"><i class="mdi mdi-litecoin h2 text-info align-middle mb-0 me-3"></i> litecoin </p>

                                                <div class="row">
                                                    <div class="col-6">
                                                        <div>
                                                            <h5>$ 63.61</h5>
                                                            <p class="text-muted text-truncate mb-0">+ 1.792 ( 0.1 % ) <i class="mdi mdi-arrow-up ms-1 text-success"></i></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div>
                                                            <div id="area-sparkline-chart-3" data-colors='["--bs-info"]' class="apex-charts"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    <?php include("footer.php") ?>
                </div>
            </div>  
           

        </div>
        <div class="right-bar">
            <div data-simplebar class="h-100">
                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="light-mode-switch" checked>
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-mode-switch">
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
                </div>

            </div> 
        </div>
        <div class="rightbar-overlay"></div>
        <script src="assets/libs/jquery/jquery.min.js"></script>   
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        
        <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
        <script src="assets/js/pages/crypto-dashboard.init.js"></script>
        <script src="assets/js/pages/saas-dashboard.init.js"></script>
        <script src="assets/js/app.js"></script>
    </body>

</html>

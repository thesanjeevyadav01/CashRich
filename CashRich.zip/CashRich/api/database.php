<?php 

$dbserver ="localhost";
$dbusername = "root";
$dbpassword ="";
$dbname = "cashrich";

$conn = mysqli_connect($dbserver,$dbusername,$dbpassword,$dbname);

?>
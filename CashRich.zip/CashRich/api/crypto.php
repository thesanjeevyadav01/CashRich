<html>
<script>

// var apikey = {
//     key:'48bd84c8-ca06-4b73-88d2-4e8746065603'
// }

request('GET','https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=BTC,ETHLTC?CMC_PRO_API_KEY=48bd84c8-ca06-4b73-88d2-4e8746065603')
.then((r1) => {
    var x1 = JSON.parse(r1.target.responseText);
    console.log(x1);
}).catch(err => {
    console.log(err);
})  

function request(method, url) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(method, url);
            xhr.onload = resolve;
            xhr.onerror = reject;
            xhr.send();
        });
}
</script>
</html>
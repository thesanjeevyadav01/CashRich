<?php 
include ("Database.php");

if ($_SERVER["REQUEST_METHOD"] === 'POST')
{
    $username = $_REQUEST['username'];
    $query_login = "SELECT username FROM user_login WHERE username='$username';";
                    $result_login = mysqli_query($conn,$query_login);
                    $anything_found = mysqli_num_rows($result_login);
                    if($anything_found>0)
                        {
                            
                            $data["message"] = "username already exist";
                            $data["status"] = "403";
                            echo json_encode($data);
                        return false;  }
                    
                        else { 
        $useremail = $_REQUEST['useremail'];
        $userpassword= $_REQUEST['userpassword'];

   $sql = "INSERT INTO user_login ( `username`,`email`,`password`) VALUES ('$username','$useremail','$userpassword')";
 
    
    $result = $conn->query($sql);
    if ($result == 1)
    {
        $data["message"] = "data saved successfully";
        $data["status"] = "200";
    }
    else
    {
        $data["message"] = "data not saved successfully";
        $data["status"] = "400";    
    }

}
}
else
{
    $data["message"] = "Format not supported";
    $data["status"] = "error";    
}
    echo json_encode($data);

   ?>